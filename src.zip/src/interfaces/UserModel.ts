export interface UserModel{
    name:String,
    email:String,
    password:String,
    phone:Number,
    channels:any,
    friends:any,
}