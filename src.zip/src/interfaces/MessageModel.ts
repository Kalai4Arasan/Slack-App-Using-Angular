export interface MessageModel{
    room:String,
    message:any,
}