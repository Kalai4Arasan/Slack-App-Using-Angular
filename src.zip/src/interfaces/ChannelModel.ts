export interface ChannelModel{
    channelName:String,
    channelType:String,
    createdDate:String,
    users:any,
}